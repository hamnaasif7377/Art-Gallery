# Art Gallery Website

Welcome to the Art Gallery Website project! This project showcases a dynamic and interactive website designed for displaying and ordering artwork. It includes features such as responsive design, dynamic content loading, and user interaction.

## Project Overview

The Art Gallery Website consists of three main pages:
- **Home (index.html)**: Displays a list of artwork with options to view details and place orders.
- **Order Details (events.html)**: Allows users to enter their details and confirm their order.
- **Order Confirmation (confirmation.html)**: Shows the details of the completed order and provides an option to print the confirmation.

## Technologies Used

- **HTML**: Structuring the web pages.
- **CSS**: Styling the pages with responsive design techniques.
- **JavaScript**: Adding interactivity and handling dynamic content.

## File Structure

- `index.html`: The homepage showcasing artwork with links to order details.
- `events.html`: The page where users can place an order by filling out a form.
- `confirmation.html`: The confirmation page displaying order details.
- `script.js`: Contains JavaScript code for dynamically loading content and handling form submissions.
- `styles.css`: Provides styling for the website including responsive design and visual effects.

## Features

- **Dynamic Content Loading**: Artwork is loaded dynamically using JavaScript.
- **Responsive Design**: The website adjusts its layout based on the screen size.
- **Interactive Forms**: Users can enter their details and confirm orders, with data saved in local storage for confirmation.

## Getting Started

1. Clone the repository: `git clone <repository-url>`
2. Open the `index.html` file in a web browser to view the homepage.

## Usage

- **Homepage**: Browse artwork and click "ORDER NOW" to view details.
- **Order Details**: Fill in your details and click "Confirm to Checkout" to complete the order.
- **Order Confirmation**: Review your order details and print the confirmation if needed.

## Future Improvements

- Add user authentication for managing orders.
- Implement a backend system for storing orders and user information.
- Enhance the design with more advanced CSS techniques and animations.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Contact

For any questions or feedback, please reach out to [your-email@example.com].

---

Thank you for checking out the Art Gallery Website project!
