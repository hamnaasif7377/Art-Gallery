const events = [
    {
        "id": "1",
        "title": "Musical Vibes",
        "price": "$1500",
        "description": "Artist: Picasso",
        "image": "art1.png"
    },
    {
        "id": "2",
        "title": "Face of Beauty",
        "price": "$2000",
        "description": "Artist: Picasso",
        "image": "art2.png"
    },
    {
        "id": "3",
        "title": "Deep Thoughts",
        "price": "$1800",
        "description": "Artist: Picasso",
        "image": "art3.png"
    },
    {
        "id": "4",
        "title": "Faces of Emotion",
        "price": "$2200",
        "description": "Artist: Picasso",
        "image": "art4.png"
    },
    {
        "id": "5",
        "title": "Black & White",
        "price": "$2500",
        "description": "Artist: Picasso",
        "image": "art5.png"
    },
    {
        "id": "6",
        "title": "Blooming Dreams",
        "price": "$3000",
        "description": "Artist: Claude Monet",
        "image": "art6.png"
    },
    {
        "id": "7",
        "title": "Bold Perspectives",
        "price": "$2700",
        "description": "Artist: Picasso",
        "image": "art7.png"
    },
    {
        "id": "8",
        "title": "Whispers of the Forest",
        "price": "$3500",
        "description": "Artist: Claude Monet",
        "image": "art8.png"
    },
    {
        "id": "9",
        "title": "River's Song",
        "price": "$3200",
        "description": "Artist: Claude Monet",
        "image": "art9.png"
    },
    {
        "id": "10",
        "title": "Winds of Change",
        "price": "$2800",
        "description": "Artist: Claude Monet",
        "image": "art10.png"
    },
    {
        "id": "11",
        "title": "Whispers of the Night",
        "price": "$4000",
        "description": "Artist: Claude Monet",
        "image": "art11.png"
    },
    {
        "id": "12",
        "title": "Whisked Whispers",
        "price": "$5000",
        "description": "Artist: Johannes Vermeer",
        "image": "art12.png"
    },
    {
        "id": "13",
        "title": "Quiet Waters",
        "price": "$4500",
        "description": "Artist: Johannes Vermeer",
        "image": "art13.png"
    },
    {
        "id": "14",
        "title": "Ocean's Embrace",
        "price": "$4800",
        "description": "Artist: Johannes Vermeer",
        "image": "art14.png"
    },
    {
        "id": "15",
        "title": "Floral Whispers",
        "price": "$3500",
        "description": "Artist: Claude Monet",
        "image": "art15.png"
    }
];

// Load events into the #event-list section
function loadEvents() {
    const eventList = document.getElementById('event-list');

    if (!eventList) return;

    if (events.length === 0) {
        eventList.innerHTML = '<p>No events found.</p>';
        return;
    }

    eventList.innerHTML = ''; // Clear any existing content
    events.forEach(event => {
        const card = document.createElement('div');
        card.className = 'event-card';
        card.innerHTML = `
            <img src="${event.image}" alt="${event.title}">
            <div class="content">
                <h2>${event.title}</h2>
                <p>${event.price}</p>
                <p>${event.description}</p>
                <a href="events.html?event=${event.id}">ORDER NOW</a>
            </div>
        `;
        eventList.appendChild(card);
    });
}

// Load event details based on query parameter
function loadEventDetails() {
    const params = new URLSearchParams(window.location.search);
    const eventId = params.get('event');
    if (!eventId) return;

    const event = events.find(e => e.id === eventId);

    if (!event) {
        document.getElementById('event-details').innerHTML = '<p>Event not found.</p>';
        return;
    }

    const eventDetails = document.getElementById('event-details');
    eventDetails.innerHTML = `
        <h2>${event.title}</h2>
        <p>Price: ${event.price}</p>
        <p>${event.description}</p>
        <img src="${event.image}" alt="${event.title}">
        <form id="booking-form">
            <label for="name">Name:</label>
            <input type="text" id="name" required>
            
            <label for="email">Email:</label>
            <input type="email" id="email" required>
            
            <label for="address">House Address:</label>
            <input type="text" id="address" required>
            
            <label for="country">Country:</label>
            <input type="text" id="country" required>
            
            <label for="frame-color">Frame Color:</label>
            <select id="frame-color">
                <option value="silver">Silver</option>
                <option value="black">Black</option>
                <option value="golden">Golden</option>
            </select>
            
            <button type="submit">Confirm to Checkout</button>
        </form>
    `;
    document.getElementById('event-list').style.display = 'none';
    eventDetails.style.display = 'block';
}

// Handle form submission and save booking data
function handleFormSubmission(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const address = document.getElementById('address').value;
    const country = document.getElementById('country').value;
    const frameColor = document.getElementById('frame-color').value;

    const bookingDetails = {
        name,
        email,
        address,
        country,
        frameColor,
        eventId: new URLSearchParams(window.location.search).get('event')
    };

    localStorage.setItem('bookingDetails', JSON.stringify(bookingDetails));

    window.location.href = 'confirmation.html';
}

// Display booking confirmation details
function displayBookingDetails() {
    const bookingDetails = JSON.parse(localStorage.getItem('bookingDetails'));

    if (!bookingDetails) {
        document.getElementById('booking-details').innerHTML = '<p>No booking details found.</p>';
        return;
    }

    const bookingDetailsDiv = document.getElementById('booking-details');
    bookingDetailsDiv.innerHTML = `
        <p><strong>Name:</strong> ${bookingDetails.name}</p>
        <p><strong>Email:</strong> ${bookingDetails.email}</p>
        <p><strong>House Address:</strong> ${bookingDetails.address}</p>
        <p><strong>Country:</strong> ${bookingDetails.country}</p>
        <p><strong>Frame Color:</strong> ${bookingDetails.frameColor}</p>
        <p><strong>Artwork ID:</strong> ${bookingDetails.eventId}</p>
    `;

    localStorage.removeItem('bookingDetails'); // Clear booking details after displaying
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('event-list')) {
        loadEvents();
    }
    if (document.getElementById('event-details')) {
        loadEventDetails();
    }
    if (document.getElementById('booking-form')) {
        document.getElementById('booking-form').addEventListener('submit', handleFormSubmission);
    }
    if (document.getElementById('booking-details')) {
        displayBookingDetails();
    }
});
